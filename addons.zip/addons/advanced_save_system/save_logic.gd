extends Node

# --- Configuration & Keys ---
# The base password for encryption
const BASE_PASSWORD = "Super_Secure_Base_Key_2026!@#"
# Paths where the data will be stored on the device
const MAIN_SAVE_PATH = "user://game_data.dat"
const BACKUP_SAVE_PATH = "user://system_config.cfg"

# Dictionary to hold the data during the game session
var _data: Dictionary = {}

func _ready() -> void:
	# Load existing data from the disk when the game starts
	_load_and_verify()

# --- Save Data ---
# Stores a value in a specific group and key, then saves to disk
func Save_game(group: String, name_key: String, value: Variant) -> void:
	if not _data.has(group):
		_data[group] = {}
	
	# Convert any data type to a string format for JSON storage
	_data[group][name_key] = var_to_str(value)
	# Trigger the encryption and saving process
	_full_secure_save()

# --- Load Data ---
# Retrieves a value from a group/key, returns default if not found
func get_data(group: String, name_key: String, default_value: Variant = null) -> Variant:
	if _data.has(group) and _data[group].has(name_key):
		# Convert the stored string back to its original data type
		var result = str_to_var(_data[group][name_key])
		return result if result != null else default_value
	return default_value

# --- Data Cleaning ---
# Removes an entire group of data
func clean_group(group: String) -> void:
	if _data.erase(group):
		_full_secure_save()

# Removes a specific key from a group
func clean_key(group: String, name_key: String) -> void:
	if _data.has(group) and _data[group].has(name_key):
		_data[group].erase(name_key)
		_full_secure_save()

# Resets everything and clears the save files
func clean_All() -> void:
	_data.clear()
	_full_secure_save()

# --- Internal Security Logic ---
# Handles saving the dictionary to two separate encrypted files
func _full_secure_save() -> void:
	var json_string = JSON.stringify(_data)
	_write_encrypted(MAIN_SAVE_PATH, json_string)
	_write_encrypted(BACKUP_SAVE_PATH, json_string)

# Encrypts the data using a password unique to the user's device
func _write_encrypted(path: String, content: String) -> void:
	# Generate unique password using the device ID
	var password = (BASE_PASSWORD + OS.get_unique_id()).sha256_text()
	
	# Create a package containing the data and a hash for verification
	var data_with_hash = JSON.stringify({
		"data": content,
		"hash": content.sha256_text()
	})
	
	# Open file with encryption and store the string
	var file = FileAccess.open_encrypted_with_pass(path, FileAccess.WRITE, password)
	if file:
		file.store_string(data_with_hash)
		file.close()

# Reads and decrypts the file, verifying its integrity
func _read_encrypted(path: String) -> String:
	if not FileAccess.file_exists(path): return ""
	var password = (BASE_PASSWORD + OS.get_unique_id()).sha256_text()
	var file = FileAccess.open_encrypted_with_pass(path, FileAccess.READ, password)
	if file:
		var content = file.get_as_text()
		file.close()
		
		var parsed = JSON.parse_string(content)
		if parsed and parsed.has("data") and parsed.has("hash"):
			# Check if the data hash matches to ensure it wasn't tampered with
			if parsed.data.sha256_text() == parsed.hash:
				return parsed.data
	return ""

# --- Backup & Recovery Logic ---
# Checks both save files and recovers data if one is corrupted
func _load_and_verify() -> void:
	var main_content = _read_encrypted(MAIN_SAVE_PATH)
	var backup_content = _read_encrypted(BACKUP_SAVE_PATH)
	
	if main_content != "" and backup_content != "" and main_content == backup_content:
		_data = JSON.parse_string(main_content)
	elif backup_content != "":
		# If main is broken, use backup
		_data = JSON.parse_string(backup_content)
		_full_secure_save()
	elif main_content != "":
		# If backup is broken, use main
		_data = JSON.parse_string(main_content)
		_full_secure_save()
	else:
		# No data found
		_data = {}
