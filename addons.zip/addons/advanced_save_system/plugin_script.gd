@tool
extends EditorPlugin

# اسم الـ Singleton الذي سيستخدمه المطور في الكود (مثلاً Save.Save_game)
const AUTOLOAD_NAME = "Save"

func _enter_tree():
	# تسجيل السكريبت كـ AutoLoad تلقائياً
	# المعامل الأول: الاسم البرمجي | المعامل الثاني: مسار ملف الكود الخاص بك
	add_autoload_singleton(AUTOLOAD_NAME, "res://addons/advanced_save_system/save_logic.gd")
	print("نظام الحفظ الذكي جاهز للاستخدام كـ Global!")

func _exit_tree():
	# إزالة الـ AutoLoad عند تعطيل الإضافة لتنظيف المشروع
	remove_autoload_singleton(AUTOLOAD_NAME)
	print("تم إزالة نظام الحفظ.")
